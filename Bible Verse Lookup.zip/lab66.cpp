/*********************************************************
* Summary: 
*
* Author: 
* Created: 
*
********************************************************/

#include <iostream>
#include <cstdlib>
#include <fstream>

using namespace std;

int main() {
   
   /* your code here */

   return 0;
}
